class Dog
  def initialize(name, age, breed)
    @name = name
    @breed = breed
    @age = age
  end
end

class Doggo < Dog

end
